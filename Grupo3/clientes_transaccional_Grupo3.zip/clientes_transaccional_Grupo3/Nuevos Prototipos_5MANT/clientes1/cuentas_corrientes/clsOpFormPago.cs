﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace cuentas_corrientes
{
    class clsOpFormPago
    {
        public static int Agregar(clsFomPago tp) //Para insertar datos a Mysql 
        {
            int iretorno = 0;
            MySqlCommand comando = new MySqlCommand(string.Format("insert into forma_pago (id_forma_pk,tipo_pago, descripcion) values (NULL,'{0}','{1}')",
               tp.stp, tp.sdecripcion), cls_bdcomun.ObtenerConexion());
            iretorno = comando.ExecuteNonQuery();// Retorna un 1 si se ejecuta la inserción y 0 es error.
            return iretorno;

        }



        public static List<clsFomPago> Buscar(string nomtp) //Método tipo lista, que retornar el resultado dela busqueda
        {
            List<clsFomPago> _lista = new List<clsFomPago>();

            MySqlCommand _comando = new MySqlCommand(String.Format(
           "select id_forma_pk, tipo_pago, descripcion from forma_pago where tipo_pago ='{0}' ", nomtp), cls_bdcomun.ObtenerConexion());
            // "select id_impuesto, porcentaje, nombre, descripcion from categoria  where nombre_cat ='{0}' ", nomcat),
            MySqlDataReader _reader = _comando.ExecuteReader();
            while (_reader.Read())
            {
               clsFomPago  ptp = new clsFomPago();
                ptp.icod = _reader.GetInt16(0);
                
                ptp.stp = _reader.GetString(1);
                ptp.sdecripcion = _reader.GetString(2);

                _lista.Add(ptp);
            }

            return _lista;
        }

        public static clsFomPago Obtenerimp(int id_itp)
        {
          
            MySqlConnection conexion = cls_bdcomun.ObtenerConexion();
            clsFomPago ptp = new clsFomPago();

            MySqlCommand _comando = new MySqlCommand(String.Format("select id_forma_pk, tipo_pago, descripcion from forma_pago  where id_forma_pk ='{0}' ", id_itp), conexion);
            MySqlDataReader _reader = _comando.ExecuteReader();
            while (_reader.Read())
            {
                ptp.icod = _reader.GetInt16(0);

                ptp.stp = _reader.GetString(1);
                ptp.sdecripcion = _reader.GetString(2);
            }

            conexion.Close();
            return ptp;
        }


        public static int Actualizar(clsFomPago ptp)
        {
            int iretorno = 0;
            MySqlConnection conexion = cls_bdcomun.ObtenerConexion();
            MySqlCommand comando = new MySqlCommand(string.Format("update forma_pago set tipo_pago='{0}', descripcion='{1}' where id_forma_pk={2}",
             ptp.stp, ptp.sdecripcion, ptp.icod), conexion);
            iretorno = comando.ExecuteNonQuery();
            conexion.Close();

            return iretorno;


        }

        public static int Eliminar(int pId)
        {
            int retorno = 0;
            MySqlConnection conexion = cls_bdcomun.ObtenerConexion();

            MySqlCommand comando = new MySqlCommand(string.Format("delete from forma_pago where id_forma_pk={0}", pId), conexion);

            retorno = comando.ExecuteNonQuery();
            conexion.Close();

            return retorno;

        }
    }
}
