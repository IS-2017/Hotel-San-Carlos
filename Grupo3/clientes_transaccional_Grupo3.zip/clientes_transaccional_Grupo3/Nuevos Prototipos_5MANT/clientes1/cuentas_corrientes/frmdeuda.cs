﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace cuentas_corrientes
{
    public partial class frmdeuda : Form
    {
        public frmdeuda(cls_deuda imp)
        {
            InitializeComponent();
            try
            {

                if (imp != null)
                {

                    ddes = imp;
                    txt_cliente.Text = Convert.ToString(imp.codclte);
                    txt_empresa.Text = Convert.ToString(imp.codemp);
                    txt_factura.Text = Convert.ToString(imp.codfac);
                    txt_monto.Text = imp.monto;
                    txt_saldot.Text = imp.saldo;
                    
                    MessageBox.Show("paso");
                }
                else
                {
                    txt_cliente.Text = "";
                    txt_empresa.Text = "";
                    txt_factura.Text = "";
                    txt_monto.Text = "";
                    txt_saldot.Text = "";
                    
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void frmFormaDePago_Load(object sender, EventArgs e)
        {

        }

        private void btn_guardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txt_cliente.Text))
                    MessageBox.Show("Campo obligatorio vacío", "Campo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                {

                    cls_deuda tc = new cls_deuda();
                    //tc.codclte = Convert.ToInt16(txt_cliente.Text.Trim());
                    //tc.codemp = Convert.ToInt16(txt_empresa.Text.Trim());
                    tc.codfac = Convert.ToInt16(txt_factura.Text.Trim());
                    tc.monto = txt_monto.Text.Trim();
                    tc.saldo = txt_saldot.Text.Trim();
                    MySqlCommand _comando = new MySqlCommand(String.Format(
                 "SELECT id_cliente_pk FROM cliente where nombre ='{0}' ", txt_cliente.Text), cls_bdcomun.ObtenerConexion());
                    MySqlDataReader _reader = _comando.ExecuteReader();
                    while (_reader.Read())
                    {

                        tc.codclte = _reader.GetInt16(0);
                    }
                    _reader.Close();

                    MySqlCommand _comando2 = new MySqlCommand(String.Format(
                 "SELECT id_empresa_pk FROM empresa where tipo ='{0}' ", txt_empresa.Text), cls_bdcomun.ObtenerConexion());
                    MySqlDataReader _reader2 = _comando2.ExecuteReader();
                    while (_reader2.Read())
                    {

                        tc.codemp = _reader2.GetInt16(0);
                    }

                    int iresultado = clsOdeuda.Agregar(tc);
                    if (iresultado > 0)
                    {
                        MessageBox.Show("Proyecto Guardado Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    else
                    {
                        MessageBox.Show("No se pudo guardar el proyecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public cls_deuda ddes { get; set; }
        private void btn_buscar_Click(object sender, EventArgs e)
        {
            try
            {
                frmBuscardeuda buscl = new frmBuscardeuda();
                buscl.ShowDialog();


                if (buscl.descl != null)
                {
                    ddes = buscl.descl;
                    //txt_cliente.Text = buscl.descl.nombre;
                    //txt_empresa.Text = buscl.descl.apellido;
                    txt_factura.Text = Convert.ToString(buscl.descl.codfac);
                    txt_monto.Text = buscl.descl.monto;
                    txt_saldot.Text = buscl.descl.saldo;
                    
                    MySqlCommand _comando = new MySqlCommand(String.Format(
                "SELECT nombre FROM cliente where id_cliente_pk ='{0}' ", buscl.descl.codclte), cls_bdcomun.ObtenerConexion());
                    MySqlDataReader _reader = _comando.ExecuteReader();
                    while (_reader.Read())
                    {

                        txt_cliente.Text = _reader.GetString(0);
                    }
                    _reader.Close();

                    MySqlCommand _comando2 = new MySqlCommand(String.Format(
                "SELECT nombre FROM empresa where id_empresa_pk ='{0}' ", buscl.descl.codemp), cls_bdcomun.ObtenerConexion());
                    MySqlDataReader _reader2 = _comando2.ExecuteReader();
                    while (_reader2.Read())
                    {

                        txt_empresa.Text = _reader2.GetString(0);
                    }

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            //mostrar();
        }

        private void btn_editar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txt_cliente.Text))

                    MessageBox.Show("Campo obligatorio vacío", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                {


                    cls_deuda cl = new cls_deuda();
                    //cl.codclte = Convert.ToInt16(txt_cliente.Text.Trim());
                    //cl.codemp = Convert.ToInt16(txt_empresa.Text.Trim());
                    cl.codfac = Convert.ToInt16(txt_factura.Text.Trim());
                    cl.monto = txt_monto.Text.Trim();
                    cl.saldo = txt_saldot.Text.Trim();
                    
                    MySqlCommand _comando = new MySqlCommand(String.Format(
                 "SELECT id_cliente_pk FROM cliente where nombre ='{0}' ", txt_cliente.Text), cls_bdcomun.ObtenerConexion());
                    MySqlDataReader _reader = _comando.ExecuteReader();
                    while (_reader.Read())
                    {

                        cl.codclte = _reader.GetInt16(0);
                    }
                    _reader.Close();

                    MySqlCommand _comando2 = new MySqlCommand(String.Format(
                 "SELECT id_empresa_pk FROM empresa where tipo ='{0}' ", txt_empresa.Text), cls_bdcomun.ObtenerConexion());
                    MySqlDataReader _reader2 = _comando2.ExecuteReader();
                    while (_reader2.Read())
                    {

                        cl.codemp = _reader2.GetInt16(0);
                    }

                    cl.cod = ddes.cod;

                    int iresultado = clsOdeuda.Actualizar(cl);
                    if (iresultado > 0)
                    {
                        MessageBox.Show("Proyecto actualizado Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    else
                    {
                        MessageBox.Show("No se pudo actualizar el proyecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            //mostrar();
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Esta Seguro que desea eliminar el proyecto Actual", "Estas Seguro??", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (clsOtcredi.Eliminar(ddes.cod) > 0)
                    {
                        MessageBox.Show("Proyecto Eliminado Correctamente!", "Proyecto Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    else
                    {
                        MessageBox.Show("No se pudo eliminar el proyecto", "Proyecto No Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                else
                    MessageBox.Show("Se cancelo la eliminacion", "Eliminacion Cancelada", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            //mostrar();        
        }
    }
}
