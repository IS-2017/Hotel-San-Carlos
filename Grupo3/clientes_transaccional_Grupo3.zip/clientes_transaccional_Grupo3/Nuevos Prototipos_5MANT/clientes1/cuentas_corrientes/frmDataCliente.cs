﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace cuentas_corrientes
{
    public partial class frmDataCliente : Form
    {
        public frmDataCliente()
        {
            InitializeComponent();
            MySqlConnection conexion = cls_bdcomun.ObtenerConexion();
            MySqlDataAdapter dausuario = new MySqlDataAdapter("SELECT * FROM cliente", conexion);
            DataSet dsuario = new DataSet();
            dausuario.Fill(dsuario, "nombre");
            dgv_cliente.DataSource = dsuario;
            dgv_cliente.DataMember = "nombre";

        }

        public cls_cliente ImpSelec { get; set; }
        private void btn_nuevo_Click(object sender, EventArgs e)
        {
            if (dgv_cliente.SelectedRows.Count == 1)
            {
                int id = Convert.ToInt16(dgv_cliente.CurrentRow.Cells[0].Value);
                ImpSelec = clsOcliente.Obtenerclte(id);
                cuentas_corrientes.frmcliente impe = new cuentas_corrientes.frmcliente(ImpSelec);
                impe.ShowDialog();

            }
            else
            {
                frmcliente tem = new frmcliente(ImpSelec);
                tem.ShowDialog();
            }
        }
    }
}
