﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cuentas_corrientes
{
    public partial class frm_cotizaciones : Form
    {
        public frm_cotizaciones()
        {
            InitializeComponent();
        }
        public bien bienseleccionado {get; set;}
        public encabezado encabezadoseleccionado { get; set; }
        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection cn = cls_bdcomun.ObtenerConexion();
            DataTable dt = new DataTable();
            String query = "Select * from cotizacion";
            MySqlCommand cmd = new MySqlCommand(query, cn);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);

            da.Fill(dt);
            dgv_cotizaciones.DataSource = dt;
        }

        private void btn_agregar_Click(object sender, EventArgs e)
        {
            frmCotizacion frm = new frmCotizacion();
            frm.Show();
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            if (dgv_cotizaciones.SelectedRows.Count > 0)
            {
                int id_cotizacion = Convert.ToInt32(dgv_cotizaciones.CurrentRow.Cells[0].Value);
                //bienseleccionado = cls_cotizaciondal.ObtenerProveedor(id_bien_pk);
                //MessageBox.Show();
                this.Close();
                if (MessageBox.Show("Esta Seguro que desea eliminar la cotizacion seleccionada", "Estas Seguro??", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)

                {

                    if (cls_cotizaciondal.Eliminar(id_cotizacion) > 0)

                    {

                        MessageBox.Show("Cotizacion Eliminada Correctamente!", "Cliente Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }

                    else

                    {

                        MessageBox.Show("No se pudo eliminar la Cotizacion", "Cotizacion No Eliminada", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                    }

                }

                else
                {

                    MessageBox.Show("Se cancelo la eliminacion", "Eliminacion Cancelada", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                /*txt_nombre.Clear();
                txt_direccion.Clear();
                txt_nit.Clear();
                txt_observaciones.Clear();
                txt_razon.Clear();
                usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Eliminar", "proveedor");*/
            }
            else
                MessageBox.Show("debe de seleccionar una fila");
        }

        private void btn_aceptar_Click(object sender, EventArgs e)
        {
            if (dgv_cotizaciones.SelectedRows.Count > 0)
            {
                int id_cotizacion = Convert.ToInt32(dgv_cotizaciones.CurrentRow.Cells[0].Value);
                //bienseleccionado = cls_cotizaciondal.ObtenerProveedor(id_bien_pk);
                //MessageBox.Show();
            }
            this.Close();
       }
    }
}
