﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cuentas_corrientes
{
    public partial class frmCotizacion : Form
    {
        public frmCotizacion()
        {
            InitializeComponent();
        }
        public bien bienseleccioando { get; set; }
        int cont = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            frmBuscarProducto frm = new frmBuscarProducto();
            frm.ShowDialog();


            if (frm.bienseleccionado != null)
            {

                //frm.ShowDialog();
                dataGridView1.Rows.Add(1);
                if (dataGridView1.Rows.Count == 0)
                {
                    //frm.ShowDialog();
                    bienseleccioando = frm.bienseleccionado;
                    dataGridView1.Rows[cont].Cells[1].Value = frm.bienseleccionado.descripcion;
                    dataGridView1.Rows[cont].Cells[0].Value = frm.bienseleccionado.id_bien_pk;
                    dataGridView1.Rows[cont].Cells[2].Value = frm.bienseleccionado.precio;
                    //dataGridView1.Rows.Add();
                    cont++;
                }
                else
                {
                    if (dataGridView1.Rows.Count > 1)
                    {
                        //frm.ShowDialog();
                        bienseleccioando = frm.bienseleccionado;
                        dataGridView1.Rows[cont].Cells[1].Value = frm.bienseleccionado.descripcion;
                        dataGridView1.Rows[cont].Cells[0].Value = frm.bienseleccionado.id_bien_pk;
                        dataGridView1.Rows[cont].Cells[2].Value = frm.bienseleccionado.precio;
                        //dataGridView1.Rows.Add();
                        cont++;
                    }
                }

                //dataGridView1.Rows[3].Cells[0].Value = frm.bienseleccionado.cantidad;
                MessageBox.Show(Convert.ToString(cont));
                //cont = cont + 1;

            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            cls_cotizacion cotizacion = new cls_cotizacion();
            cotizacion.nombre_cte = textBox1.Text.Trim();
            cotizacion.direccion_cte = textBox3.Text.Trim();
            cotizacion.apellido_cte = textBox2.Text.Trim();
            cotizacion.nit_cte = textBox5.Text.Trim();
            cotizacion.fecha_cot = textBox4.Text.Trim();
            cotizacion.estado_cot = comboBox1.Text.Trim();

            int resultado = cls_cotizaciondal.Agregar(cotizacion);
            if (resultado > 0)
             {
                 MessageBox.Show("Cotizacion Guardada Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
             }
             else
             {
                 MessageBox.Show("No se pudo guardar la Cotizacion", "Fallo!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
             }
            /*if (resultado > 0)
            {
                MessageBox.Show("Encabezado de factura guardado Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);

                //Insertando en detalle de factura 
                int filas = dataGridView1.RowCount;



                MySqlConnection conectar3 = cls_bdcomun.ObtenerConexion();
                detalle_cot imp3 = new detalle_cot();
                MySqlCommand _comando3 = new MySqlCommand(String.Format(
                     "SELECT MAX(id_cotizacion) from cotizacion "), conectar3);
                MySqlDataReader _reader3 = _comando3.ExecuteReader();
                while (_reader3.Read())
                {

                    imp3.id_cotizacion_pk = _reader3.GetInt16(0); //Id impuestp
                }
                conectar3.Close();


                for (int f = 0; f < filas; f++)
                {


                    detalle_cot defact = new detalle_cot();
                    defact.id_cotizacion_pk = imp3.id_cotizacion_pk;
                    //defact.cod_emp = fact.cod_emp;
                    //defact.serie = fact.serie;
                    defact.cantidad_detallecot = Convert.ToInt16(dataGridView1.Rows[f].Cells[3].Value);
                    defact = Convert.ToInt16(dgv_detallefact.Rows[f].Cells[3].Value);
                    MessageBox.Show(Convert.ToString(defact.cantidad));
                    defact.descripcion = Convert.ToString(dgv_detallefact.Rows[f].Cells[2].Value);
                    defact.prec = Convert.ToInt16(dgv_detallefact.Rows[f].Cells[3].Value);
                    defact.subtotal = Convert.ToInt16(dgv_detallefact.Rows[f].Cells[4].Value);

                    int iresultado1 = cls_cotizaciondal.AgregarDetFact(defact);
                    if (iresultado1 > 0)
                    {
                        MessageBox.Show("Detalle insertado correctamente");

                    }
                    else
                    {
                        MessageBox.Show("No se inserto detalle");
                    }
                }


            }
            else
            {
                MessageBox.Show("No se pudo guardar el encabezado de factura", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }     
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }*/


            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            comboBox1.ResetText();
            textBox7.Clear();

        } 

        private void button2_Click(object sender, EventArgs e)
        {
            frmBuscarPromociones frm = new frmBuscarPromociones();
            frm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmBuscarPaquete frm = new frmBuscarPaquete();
            frm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void frmCotizacion_Load(object sender, EventArgs e)
        {
            
                /*dataGridView1.AutoGenerateColumns = false;
                dataGridView1.DataSource = ();

                dataGridView1.DataSource = CargarProductosDT();

                //Tamaño de cada columna
                foreach (DataGridViewColumn columna in dataGridView1.Columns)
                {
                    columna.Width = 118;
                }*/
            
        }
    }
    }

