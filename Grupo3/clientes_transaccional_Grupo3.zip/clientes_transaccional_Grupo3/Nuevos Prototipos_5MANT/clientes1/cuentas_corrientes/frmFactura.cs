﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace cuentas_corrientes
{
    public partial class frmFactura : Form
    {
        public frmFactura()
        {
            InitializeComponent();
            llenar();
        }

        public void llenar()
        {
            cbo_serie.Items.Add("A");
            cbo_serie.Items.Add("B");
            cbo_serie.Items.Add("C");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txt_fecemi_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmFactura_Load(object sender, EventArgs e)
        {

           // button1.Enabled = false;
            //button2.Enabled = false;
            //button3.Enabled = false;

            string scad = "select * from forma_pago";
            MySqlCommand mcd = new MySqlCommand(scad, cls_bdcomun.ObtenerConexion());
            MySqlDataReader mdr = mcd.ExecuteReader();
            while (mdr.Read())
            {
                cbo_formpago.Items.Add(mdr.GetString("tipo_pago"));
            }
        }

        private void cbo_formpago_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        public cls_cliente cldes { get; set; }

        private void btn_Buscte_Click(object sender, EventArgs e)
        {
            try
            {
                frmbuscliente buscl = new frmbuscliente();
                buscl.ShowDialog();


                if (buscl.descl != null)
                {
                    cldes = buscl.descl;
                    txt_nombre.Text = buscl.descl.nombre;
                   
                    txt_nit.Text = buscl.descl.nit;
                    txt_dir.Text = buscl.descl.dire;
                   

                  

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void btn_nuevo_Click(object sender, EventArgs e)
        {
            //button1.Enabled = true;
            //button2.Enabled = true;
            //button3.Enabled = true;
        }

        private void cbo_serie_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
