﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace cuentas_corrientes
{
    public partial class frmDataDeuda : Form
    {
        public frmDataDeuda()
        {
            InitializeComponent();
            MySqlConnection conexion = cls_bdcomun.ObtenerConexion();
            MySqlDataAdapter dausuario = new MySqlDataAdapter("SELECT * FROM deuda", conexion);
            DataSet dsuario = new DataSet();
            dausuario.Fill(dsuario, "nombre");
            dgv_deuda.DataSource = dsuario;
            dgv_deuda.DataMember = "nombre";

        }

        public cls_deuda ImpSelec { get; set; }
        private void btn_nuevo_Click(object sender, EventArgs e)
        {
            if (dgv_deuda.SelectedRows.Count == 1)
            {
                int id = Convert.ToInt16(dgv_deuda.CurrentRow.Cells[0].Value);
                ImpSelec = clsOdeuda.Obtenerdeu(id);
                cuentas_corrientes.frmdeuda impe = new cuentas_corrientes.frmdeuda(ImpSelec);
                impe.ShowDialog();

            }
            else
            {
                frmdeuda tem = new frmdeuda(ImpSelec);
                tem.ShowDialog();
            }
        }
    }
}
