﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace cuentas_corrientes
{
    public partial class frmDataParmFact : Form
    {
        public frmDataParmFact()
        {
            InitializeComponent();

            MySqlConnection conexion = cls_bdcomun.ObtenerConexion();
            MySqlDataAdapter dausuario = new MySqlDataAdapter("SELECT * FROM parametros_fac", conexion);
            DataSet dsuario = new DataSet();
            dausuario.Fill(dsuario, "nombre");
            dgv_paramfact.DataSource = dsuario;
            dgv_paramfact.DataMember = "nombre";
        }

        public clsParamFact facSelec { get; set; }
        private void btn_nuevo_Click(object sender, EventArgs e)
        {
            if (dgv_paramfact.SelectedRows.Count == 1)
            {
                int id = Convert.ToInt16(dgv_paramfact.CurrentRow.Cells[0].Value);
                facSelec = clsOpParmFact.ObtenerParmFact(id);
                cuentas_corrientes.frmParametrosFact impe = new cuentas_corrientes.frmParametrosFact(facSelec);
                impe.ShowDialog();

            }
            else
            {
                frmParametrosFact tem = new frmParametrosFact(facSelec);
                tem.ShowDialog();
            }
        }

        private void dgv_paramfact_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
