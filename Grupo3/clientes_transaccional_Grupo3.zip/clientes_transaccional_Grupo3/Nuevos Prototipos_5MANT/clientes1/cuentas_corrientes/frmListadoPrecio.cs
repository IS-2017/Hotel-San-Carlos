﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace cuentas_corrientes
{
    public partial class frmListadoPrecio : Form
    {
        public frmListadoPrecio()
        {
            InitializeComponent();
            llenar_evento();
            llenar_habitacion();
            llenar_paquete();
            llenar_bien();
        }

        public void llenar_evento()
        {
            DataGridViewTextBoxColumn c1 = new DataGridViewTextBoxColumn();
            c1.HeaderText = "Evento";
            c1.Width = 100;
            c1.ReadOnly = true;

            dgv_evento.Columns.Add(c1);

            DataGridViewTextBoxColumn c2 = new DataGridViewTextBoxColumn();
            c2.HeaderText = "Precio";
            c2.Width = 50;
            c2.ReadOnly = true;

            dgv_evento.Columns.Add(c2);

            string scad = "SELECT * FROM precio INNER JOIN evento ON evento.id_evento_pk = precio.id_evento_pk";
            MySqlCommand mcd = new MySqlCommand(scad, cls_bdcomun.ObtenerConexion());
            MySqlDataReader mdr = mcd.ExecuteReader();

            while (mdr.Read())
            {
                
                dgv_evento.Rows.Add(mdr.GetString("nombre"),mdr.GetString("precio"));

            }
       

        }
        public void llenar_habitacion()
        {
            DataGridViewTextBoxColumn c1 = new DataGridViewTextBoxColumn();
            c1.HeaderText = "Habitacion";
            c1.Width = 100;
            c1.ReadOnly = true;

            dgv_habitacion.Columns.Add(c1);

            DataGridViewTextBoxColumn c2 = new DataGridViewTextBoxColumn();
            c2.HeaderText = "Precio";
            c2.Width = 50;
            c2.ReadOnly = true;

            dgv_habitacion.Columns.Add(c2);

            string scad = "SELECT * FROM precio INNER JOIN habitacion INNER JOIN tipo ON precio.id_habitacion_pk = habitacion.id_habitacion_pk and tipo.id_tipo_pk = habitacion.id_tipo_pk";
            MySqlCommand mcd = new MySqlCommand(scad, cls_bdcomun.ObtenerConexion());
            MySqlDataReader mdr = mcd.ExecuteReader();


            while (mdr.Read())
            {

                dgv_habitacion.Rows.Add(mdr.GetString("nombre"), mdr.GetString("precio"));

            }
        }

        public void llenar_paquete()
        {
            DataGridViewTextBoxColumn c1 = new DataGridViewTextBoxColumn();
            c1.HeaderText = "Paquetenamores";
            c1.Width = 100;
            c1.ReadOnly = true;

            dgv_habitacion.Columns.Add(c1);

            DataGridViewTextBoxColumn c2 = new DataGridViewTextBoxColumn();
            c2.HeaderText = "Precio";
            c2.Width = 50;
            c2.ReadOnly = true;

            dgv_paquete.Columns.Add(c2);

            string scad = "SELECT * FROM precio INNER JOIN promocion ON promocion.id_promocion_pk = precio.id_promocion_pk";
            MySqlCommand mcd = new MySqlCommand(scad, cls_bdcomun.ObtenerConexion());
            MySqlDataReader mdr = mcd.ExecuteReader();


            while (mdr.Read())
            {

                dgv_paquete.Rows.Add(mdr.GetString("nombre"), mdr.GetString("precio"));

            }
        }

        public void llenar_bien()
        {
            DataGridViewTextBoxColumn c1 = new DataGridViewTextBoxColumn();
            c1.HeaderText = "Bien";
            c1.Width = 100;
            c1.ReadOnly = true;

            dgv_listadoprecio.Columns.Add(c1);

            DataGridViewTextBoxColumn c2 = new DataGridViewTextBoxColumn();
            c2.HeaderText = "Precio";
            c2.Width = 50;
            c2.ReadOnly = true;

            dgv_listadoprecio.Columns.Add(c2);

            string scad = "SELECT * FROM precio INNER JOIN bien ON bien.id_bien_pk = precio.id_bien_pk";
            MySqlCommand mcd = new MySqlCommand(scad, cls_bdcomun.ObtenerConexion());
            MySqlDataReader mdr = mcd.ExecuteReader();

            while (mdr.Read())
            {

                dgv_evento.Rows.Add(mdr.GetString("nombre"), mdr.GetString("precio"));

            }
        }

        private void btn_Buscte_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void frmListadoPrecio_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            string scad = "select * from evento";
            MySqlCommand mcd = new MySqlCommand(scad, cls_bdcomun.ObtenerConexion());
            MySqlDataReader mdr = mcd.ExecuteReader();
            int i = 1;
            while (mdr.Read())
            {
                
                float costo = Convert.ToInt32(mdr.GetString("costo"));
                float costo2 = Convert.ToInt32(txt_precio2.Text);
                float mult = costo * (costo2 / 100);
                float total = mult + (Convert.ToInt32(costo));
      
                MySqlCommand mcd1 = new MySqlCommand("insert into precio (precio, id_evento_pk) values(" + total + ","+i+")", cls_bdcomun.ObtenerConexion());
                MySqlDataReader mdr1 = mcd1.ExecuteReader();
                i++;
                costo = 0;
                costo2 = 0;
                mult = 0;
                total = 0;
            }
        }

        private void dgv_evento_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

            string scad = "select * from tipo, habitacion where tipo.id_tipo_pk = habitacion.id_tipo_pk";
            MySqlCommand mcd = new MySqlCommand(scad, cls_bdcomun.ObtenerConexion());
        
            MySqlDataReader mdr = mcd.ExecuteReader();
            int i = 1;
            while (mdr.Read())
            {

                float costo = Convert.ToInt32(mdr.GetString("costo_tipo"));
                float costo2 = Convert.ToInt32(txt_precio3.Text);
                float mult = costo * (costo2 / 100);
                float total = mult + (Convert.ToInt32(costo));

                MySqlCommand mcd1 = new MySqlCommand("insert into precio (precio, id_habitacion_pk) values(" + total + "," + i + ")", cls_bdcomun.ObtenerConexion());
                MySqlDataReader mdr1 = mcd1.ExecuteReader();
                i++;
                costo = 0;
                costo2 = 0;
                mult = 0;
                total = 0;
            }
        
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string scad = "select * from promocion";
            MySqlCommand mcd = new MySqlCommand(scad, cls_bdcomun.ObtenerConexion());
            MySqlDataReader mdr = mcd.ExecuteReader();
            int i = 1;
            while (mdr.Read())
            {

                float costo = Convert.ToInt32(mdr.GetString("costo"));
                float costo2 = Convert.ToInt32(txt_precio2.Text);
                float mult = costo * (costo2 / 100);
                float total = mult + (Convert.ToInt32(costo));

                MySqlCommand mcd1 = new MySqlCommand("insert into precio (precio, id_promocion_pk) values(" + total + "," + i + ")", cls_bdcomun.ObtenerConexion());
                MySqlDataReader mdr1 = mcd1.ExecuteReader();
                i++;
                costo = 0;
                costo2 = 0;
                mult = 0;
                total = 0;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string scad = "select * from bien";
            MySqlCommand mcd = new MySqlCommand(scad, cls_bdcomun.ObtenerConexion());
            MySqlDataReader mdr = mcd.ExecuteReader();
            int i = 1;
            while (mdr.Read())
            {

                float costo = Convert.ToInt32(mdr.GetString("costo"));
                float costo2 = Convert.ToInt32(txt_precio2.Text);
                float mult = costo * (costo2 / 100);
                float total = mult + (Convert.ToInt32(costo));

                MySqlCommand mcd1 = new MySqlCommand("insert into precio (precio, id_bien_pk) values(" + total + "," + i + ")", cls_bdcomun.ObtenerConexion());
                MySqlDataReader mdr1 = mcd1.ExecuteReader();
                i++;
                costo = 0;
                costo2 = 0;
                mult = 0;
                total = 0;
            }
        }
    }
}
