﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace cuentas_corrientes
{
    public partial class frmDataFormaPago : Form
    {
        public frmDataFormaPago()
        {
            InitializeComponent();

            MySqlConnection conexion = cls_bdcomun.ObtenerConexion();
            MySqlDataAdapter dausuario = new MySqlDataAdapter("SELECT * FROM forma_pago", conexion);
            DataSet dsuario = new DataSet();
            dausuario.Fill(dsuario, "nombre");
            dgv_formapago.DataSource = dsuario;
            dgv_formapago.DataMember = "nombre";
        }

        private void frmDataFormaPago_Load(object sender, EventArgs e)
        {

        }

        public clsFomPago fmSelec { get; set; }
        private void btn_nuevo_Click(object sender, EventArgs e)
        {
            if (dgv_formapago.SelectedRows.Count == 1)
            {
                int id = Convert.ToInt16(dgv_formapago.CurrentRow.Cells[0].Value);
                fmSelec = clsOpFormPago.Obtenerimp(id);
                cuentas_corrientes.frmFormaDePago impe = new cuentas_corrientes.frmFormaDePago(fmSelec);
                impe.ShowDialog();

            }
            else
            {
                frmFormaDePago tem = new frmFormaDePago(fmSelec);
                tem.ShowDialog();
            }
        }

        private void dgv_formapago_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
