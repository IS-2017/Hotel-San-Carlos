﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace cuentas_corrientes
{
    public partial class frmDataTipoCredito : Form
    {
        public frmDataTipoCredito()
        {
            InitializeComponent();

            InitializeComponent();
            MySqlConnection conexion = cls_bdcomun.ObtenerConexion();
            MySqlDataAdapter dausuario = new MySqlDataAdapter("SELECT * FROM tipo_credito", conexion);
            DataSet dsuario = new DataSet();
            dausuario.Fill(dsuario, "nombre");
            dgv_tipocred.DataSource = dsuario;
            dgv_tipocred.DataMember = "nombre";
        }

        public cls_tcredi ImpSelec { get; set; }
        private void btn_nuevo_Click(object sender, EventArgs e)
        {
            if (dgv_tipocred.SelectedRows.Count == 1)
            {
                int id = Convert.ToInt16(dgv_tipocred.CurrentRow.Cells[0].Value);
                ImpSelec = clsOtcredi.Obtenercredi(id);
                cuentas_corrientes.frmTipocredito impe = new cuentas_corrientes.frmTipocredito(ImpSelec);
                impe.ShowDialog();

            }
            else
            {
                frmTipocredito tem = new frmTipocredito(ImpSelec);
                tem.ShowDialog();
            }
        }
    }
}
