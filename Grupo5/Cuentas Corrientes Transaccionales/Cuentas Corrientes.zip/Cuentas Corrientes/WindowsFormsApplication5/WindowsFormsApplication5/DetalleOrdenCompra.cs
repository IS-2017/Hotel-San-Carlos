﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApplication5
{
    public partial class DetalleOrdenCompra : Form
    {
        public DetalleOrdenCompra()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
