﻿using System;
using System.Windows.Forms;

namespace ComprasProveedores
{
    public partial class InsertarCompra : Form
    {
        public InsertarCompra()
        {
            InitializeComponent();
        }

        private void gpb_gastos_importacion_Enter(object sender, EventArgs e)
        {

        }
    }
}
