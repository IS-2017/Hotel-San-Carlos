﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication5
{
    public partial class pagar : Form
    {
        public pagar()
        {
            InitializeComponent();
        }

        private void pagar_Load(object sender, EventArgs e)
        {
            ManejoProveedor mp = new ManejoProveedor();
            mp.llenar_id_pro_detalle(cbo_proveedor);
            cbo_proveedor.SelectedIndex = -1;
        }

        private void btn_generar_Click(object sender, EventArgs e)
        {
            
            ManejoProveedor mp = new ManejoProveedor();
            string comp = mp.Generar_Comprobante();
            DataTable d = mp.cargar("select sum(debe),max(saldo),id_proveedor_pk,id_cuenta_pk from detalle_cuenta_por_pagar where id_proveedor_pk='" + cbo_proveedor.SelectedValue.ToString() + "'");
            label2.Text = Convert.ToString(d.Rows.Count);
            if (d.Rows.Count == 1)
            {
                    int debe = Convert.ToInt32(d.Rows[0][0].ToString());
                    string id_cuenta = Convert.ToString(d.Rows[0][3].ToString());
                    string id_pro = Convert.ToString(d.Rows[0][2].ToString());
                    int saldo = Convert.ToInt32(d.Rows[0][1].ToString());
                    if(saldo == debe)
                     {
                       mp.GenerarPago(id_cuenta, id_pro, comp, Convert.ToString(debe),"0");
                  //   MessageBox.Show("Cuenta Cancelada Exitosamente");
                      }
                    else
                    {
                    int dif = debe - saldo;
                    mp.GenerarPago(id_cuenta, id_pro, comp, Convert.ToString(dif), "0");
                   // MessageBox.Show("Cuenta Cancelada Existosamente");
                    }   

                            
            }
                        
            else
            {
                MessageBox.Show("No Hay Detalle");
            }

        }
    }
}
