﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication5
{
    public partial class proveedor : Form
    {
        public proveedor()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void proveedor_Load(object sender, EventArgs e)
        {
            ManejoProveedor mp = new ManejoProveedor();
            DataTable dt = mp.cargar("select * from proveedor where estado='ACTIVO'");
            dgv_proveedor.DataSource = dt;
            dgv_proveedor.Columns[0].HeaderText = "ID Proveedor";
            dgv_proveedor.Columns[1].HeaderText = "Nombre";
            dgv_proveedor.Columns[2].HeaderText = "Direccion";
            dgv_proveedor.Columns[3].HeaderText = "Telefono";
            dgv_proveedor.Columns[4].HeaderText = "Email";
            dgv_proveedor.Columns[5].HeaderText = "Estado"; 
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Abrir.Form1  f1= new Abrir.Form1();
            f1.Crystal = @"C:\Users\ccarrera\Desktop\Entregar\Prueba\Prueba\proveedor.rpt";
            f1.Show();
        }

        private void btn_guardar_Click(object sender, EventArgs e)
        {

        }
    }
}
