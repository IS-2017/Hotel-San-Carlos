﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication5
{
    public partial class detalle_cuenta : Form
    {
        public detalle_cuenta()
        {
            InitializeComponent();
        }

        private void detalle_cuenta_Load(object sender, EventArgs e)
        {
            
        }

        private void btn_nuevo_Click(object sender, EventArgs e)
        {
            ManejoProveedor mm = new ManejoProveedor();
            DataTable dt= mm.cargar("select detalle_cuenta_por_pagar_pk as 'ID Detalle',fecha as Fecha,comprobante as Comprobante,debe as Debe,haber as Haber,saldo as Saldo,estado as Estado from detalle_cuenta_por_pagar where id_cuenta_pk='" + txt_cuenta.Text + "'");
            dgv_detalle.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Abrir.Form1 f = new Abrir.Form1();
            f.Crystal = @"C:\Users\ccarrera\Desktop\Entregar\Prueba\Prueba\cuenta.rpt";
            f.Show();
        }
    }
}
