﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication5
{
    public partial class GenerarCuenta : Form
    {
        public GenerarCuenta()
        {
            InitializeComponent();
        }

        private void btn_generar_Click(object sender, EventArgs e)
        {
            ManejoProveedor d1 = new ManejoProveedor();
            DataTable d = d1.cargar("select id_proveedor_pk from cuenta_corriente_por_pagar where id_proveedor_pk='" + cbo_proveedor.SelectedValue.ToString() + "'");
            if(d.Rows.Count !=0)
            {
                MessageBox.Show("Cuenta Existente");
            }
            else
            {
                d1.GenerarCuenta(cbo_proveedor.SelectedValue.ToString());
                MessageBox.Show("Cuenta Se Genero Exitosamente");
                
            }
        }

        private void GenerarCuenta_Load(object sender, EventArgs e)
        {
            ManejoProveedor mp = new ManejoProveedor();
            mp.llenar_id_pro(cbo_proveedor);
            cbo_proveedor.SelectedIndex = -1;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cbo_proveedor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
