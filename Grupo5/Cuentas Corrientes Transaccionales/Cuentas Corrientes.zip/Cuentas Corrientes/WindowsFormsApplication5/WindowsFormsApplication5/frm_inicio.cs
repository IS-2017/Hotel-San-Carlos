﻿using System.Windows.Forms;

namespace WindowsFormsApplication5
{
    public partial class frm_inicio : Form
    {
        public frm_inicio()
        {
            InitializeComponent();
        }

        private void frm_inicio_Load(object sender, System.EventArgs e)
        {

        }
    }
}
