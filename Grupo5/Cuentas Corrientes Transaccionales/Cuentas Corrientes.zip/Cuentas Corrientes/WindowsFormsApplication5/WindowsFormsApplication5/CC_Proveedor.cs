﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Abrir;

namespace WindowsFormsApplication5
{
    public partial class CC_Proveedor : Form
    {
        public CC_Proveedor()
        {
            InitializeComponent();
        }

        private void btn_nuevo_Click(object sender, EventArgs e)
        {

        }

        private void CC_Proveedor_Load(object sender, EventArgs e)
        {
            try
            {
                ManejoProveedor mm = new ManejoProveedor();
                mm.llenar_id_proveedor(cbo_proveedor);
                DataTable dt = mm.cargar("Select * from cuenta_corriente_por_pagar where id_proveedor_pk='" + cbo_proveedor.SelectedValue.ToString() + "'");
                dgv_cuenta.DataSource = dt;
               
                
               
                dgv_cuenta.Columns[0].HeaderText = "ID Proveedor";
                dgv_cuenta.Columns[1].HeaderText = "NO. Cuenta";
                dgv_cuenta.Columns[2].HeaderText = "ESTADO";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Abrir.Form1 f = new Form1();
            //Ubicacion de RTP del modulo a probar
            f.Crystal = @"C:\Users\ccarrera\Desktop\Entregar\Prueba\Prueba\proveedor.rpt";
            f.StartPosition = FormStartPosition.CenterScreen;
            f.Show();
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            
            try
            {
                string id_cuenta = Convert.ToString(dgv_cuenta.CurrentRow.Cells[1].Value);
                string id_proveedor = Convert.ToString(dgv_cuenta.CurrentRow.Cells[0].Value);
                detalle_cuenta dc = new detalle_cuenta();
                ManejoProveedor mp = new ManejoProveedor();
                DataTable dd = mp.cargar("select id_cuenta_pk,id_proveedor_pk from detalle_cuenta_por_pagar where id_cuenta_pk='" + txt_cuenta.Text + "'");
                if (dd.Rows.Count != 0)
                {
                    
                        dc.txt_id_P.Text = cbo_proveedor.SelectedValue.ToString();
                        dc.txt_cuenta.Text = txt_cuenta.Text;
                        dc.Show();
                    
                }
                else
                {
                    mp.insertarDetalle(id_cuenta, id_proveedor, "0");
                    dc.txt_id_P.Text = cbo_proveedor.SelectedValue.ToString();
                    dc.txt_cuenta.Text = txt_cuenta.Text;
                    dc.Show();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cbo_proveedor_Click(object sender, EventArgs e)
        {
         
        }

        private void cbo_proveedor_DropDownClosed(object sender, EventArgs e)
        {

            try
            {
                ManejoProveedor mm = new ManejoProveedor();
                DataTable dt = mm.cargar("Select * from cuenta_corriente_por_pagar where id_proveedor_pk='" + cbo_proveedor.SelectedValue.ToString() + "'");
                dgv_cuenta.DataSource = dt;
                txt_cuenta.Text = dt.Rows[0][0].ToString();
                DataTable dt2 = mm.cargar("select * from proveedor where id_proveedor_pk='" + cbo_proveedor.SelectedValue.ToString() + "'");
                txt_nom_P.Text = dt2.Rows[0][1].ToString();
                txt_dir_P.Text = dt2.Rows[0][2].ToString();
                txt_tel_P.Text = dt2.Rows[0][3].ToString();
                txt_email_P.Text = dt2.Rows[0][4].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
