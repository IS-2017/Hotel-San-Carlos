﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
using System.Windows.Forms;

namespace WindowsFormsApplication5
{
    class ManejoProveedor
    {
        private static MySqlCommand mySqlComando;
        private static MySqlDataAdapter mySqlDAdAdaptador;
        public void llenar_id_proveedor(ComboBox cb)
        {
            try
            {

                MySqlCommand cmd;
                DataTable dt = new DataTable();

                cmd = new MySqlCommand("select  cuenta_corriente_por_pagar.id_proveedor_pk,proveedor.nombre_proveedor from proveedor inner join cuenta_corriente_por_pagar on proveedor.id_proveedor_pk = cuenta_corriente_por_pagar.id_proveedor_pk", Conexion.ObtenerConexion());
                MySqlDataAdapter adaptador = new MySqlDataAdapter(cmd);
                adaptador.Fill(dt);

                cb.DataSource = dt;
                cb.DisplayMember = "nombre_proveedor";
                cb.ValueMember = "id_proveedor_pk";

            }

            catch
            {
                MessageBox.Show("No se lleno el Combobox");
            }
        }
        public void llenar_id_pro_detalle(ComboBox cb)
        {
            try
            {

                MySqlCommand cmd;
                DataTable dt = new DataTable();

                cmd = new MySqlCommand("select * from ObtenerDetalle", Conexion.ObtenerConexion());
                MySqlDataAdapter adaptador = new MySqlDataAdapter(cmd);
                adaptador.Fill(dt);

                cb.DataSource = dt;
                cb.DisplayMember = "nombre_proveedor";
                cb.ValueMember = "id_proveedor_pk";

            }

            catch
            {
                MessageBox.Show("No se lleno el Combobox");
            }
        }
        public DataTable cargar(string query)
        {
            try
            {
                // llenado del data grid view 
                DataTable dt = new DataTable();
                MySqlCommand cmd = new MySqlCommand(query, Conexion.ObtenerConexion());
                MySqlDataAdapter adap = new MySqlDataAdapter(cmd);
                adap.Fill(dt);
                return dt;
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        public void insertarDetalle(string id_cuenta, string id_proveedor,string saldo)
        {
            try
            {
                mySqlComando = new MySqlCommand(
                string.Format("Insert into detalle_cuenta_por_pagar(id_cuenta_pk,id_proveedor_pk,saldo) values ('{0}','{1}','{2}')", id_cuenta, id_proveedor, saldo),
                Conexion.ObtenerConexion()
                );
                mySqlComando.ExecuteNonQuery();
                          
            }
            catch (MySqlException e)
            {
                MessageBox.Show("error");
            }
        }
        public string Generar_Comprobante()
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random();
            char ch;
            for (int i = 0; i < 6; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }
          
            return builder.ToString();
        }

        public void GenerarCuenta(string id_proveedor)
        {
            try
            {
                mySqlComando = new MySqlCommand(
                string.Format("Insert into cuenta_corriente_por_pagar(id_proveedor_pk) values ('{0}')", id_proveedor),
                Conexion.ObtenerConexion()
                );
                mySqlComando.ExecuteNonQuery();

            }
            catch (MySqlException e)
            {
                MessageBox.Show("error");
            }
        }
        public void GenerarPago(string id_cuenta,string id_proveedor,string comprobante,string haber,string saldo)
        {
            try
            {
               
                mySqlComando = new MySqlCommand(
                string.Format("Insert into detalle_cuenta_por_pagar(fecha,comprobante,haber,saldo,id_proveedor_pk,id_cuenta_pk) values (Sysdate(),'"+comprobante+"','"+haber+"','"+saldo+"','"+id_proveedor+"','"+id_cuenta+"')"),
                Conexion.ObtenerConexion()
                );
                mySqlComando.ExecuteNonQuery();
                MessageBox.Show("Cuenta Cancelada");

            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void llenar_id_pro(ComboBox cb)
        {
            try
            {

                MySqlCommand cmd;
                DataTable dt = new DataTable();

                cmd = new MySqlCommand("select id_proveedor_pk,nombre_proveedor from proveedor", Conexion.ObtenerConexion());
                MySqlDataAdapter adaptador = new MySqlDataAdapter(cmd);
                adaptador.Fill(dt);

                cb.DataSource = dt;
                cb.DisplayMember = "nombre_proveedor";
                cb.ValueMember = "id_proveedor_pk";

            }

            catch
            {
                MessageBox.Show("No se lleno el Combobox");
            }
        }

    }
}
