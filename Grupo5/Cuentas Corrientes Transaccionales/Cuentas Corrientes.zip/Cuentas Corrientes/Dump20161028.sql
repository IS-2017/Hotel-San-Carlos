CREATE DATABASE  IF NOT EXISTS `ejemplodll` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `ejemplodll`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: ejemplodll
-- ------------------------------------------------------
-- Server version	5.7.14-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bitacora`
--

DROP TABLE IF EXISTS `bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bitacora` (
  `usuario` varchar(20) DEFAULT NULL,
  `accion` varchar(250) DEFAULT NULL,
  `fecha_y_hora` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bitacora`
--

LOCK TABLES `bitacora` WRITE;
/*!40000 ALTER TABLE `bitacora` DISABLE KEYS */;
INSERT INTO `bitacora` VALUES ('hola','hola','99/99/99'),('hol1','hol2','2016-09-15 19:19:07');
/*!40000 ALTER TABLE `bitacora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compra`
--

DROP TABLE IF EXISTS `compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compra` (
  `id_factura_pk` int(11) NOT NULL,
  `id_orden_compra_pk` int(11) NOT NULL,
  `serie_factura` char(15) DEFAULT NULL,
  `fecha_recibida` date DEFAULT NULL,
  `encargado` char(20) DEFAULT NULL,
  `total` decimal(10,0) DEFAULT NULL,
  `id_cuenta_pk` int(11) NOT NULL,
  `id_proveedor_pk` int(11) NOT NULL,
  `id_forma_pk` int(11) NOT NULL,
  `estado` char(30) DEFAULT 'ACTIVO',
  PRIMARY KEY (`id_factura_pk`),
  KEY `Refpedido_compra7` (`id_orden_compra_pk`),
  KEY `Refcuenta_corriente_por_pagar9` (`id_cuenta_pk`,`id_proveedor_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compra`
--

LOCK TABLES `compra` WRITE;
/*!40000 ALTER TABLE `compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuenta_corriente_por_pagar`
--

DROP TABLE IF EXISTS `cuenta_corriente_por_pagar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cuenta_corriente_por_pagar` (
  `id_cuenta_pk` int(11) NOT NULL AUTO_INCREMENT,
  `id_proveedor_pk` int(11) NOT NULL,
  `estado` char(25) DEFAULT 'ACTIVO',
  PRIMARY KEY (`id_cuenta_pk`,`id_proveedor_pk`),
  KEY `Refproveedor3` (`id_proveedor_pk`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuenta_corriente_por_pagar`
--

LOCK TABLES `cuenta_corriente_por_pagar` WRITE;
/*!40000 ALTER TABLE `cuenta_corriente_por_pagar` DISABLE KEYS */;
INSERT INTO `cuenta_corriente_por_pagar` VALUES (1,1,'ACTIVO'),(2,2,'ACTIVO'),(3,3,'ACTIVO');
/*!40000 ALTER TABLE `cuenta_corriente_por_pagar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_compra`
--

DROP TABLE IF EXISTS `detalle_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_compra` (
  `id_factura_pk` int(11) NOT NULL,
  `id_detalle_pk` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `precio_compra` decimal(15,0) DEFAULT NULL,
  `subtotal_compra` decimal(15,0) DEFAULT NULL,
  `estado` char(20) DEFAULT 'ACTIVO',
  `id_orden_compra_pk` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_factura_pk`),
  KEY `Refdetalle_pedido_compra11` (`id_detalle_pk`,`id_orden_compra_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_compra`
--

LOCK TABLES `detalle_compra` WRITE;
/*!40000 ALTER TABLE `detalle_compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_cuenta_por_pagar`
--

DROP TABLE IF EXISTS `detalle_cuenta_por_pagar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_cuenta_por_pagar` (
  `detalle_cuenta_por_pagar_pk` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` varchar(25) DEFAULT NULL,
  `comprobante` char(30) DEFAULT NULL,
  `debe` decimal(15,0) DEFAULT NULL,
  `haber` decimal(15,0) DEFAULT NULL,
  `saldo` decimal(15,0) DEFAULT NULL,
  `estado` char(30) DEFAULT 'ACTIVO',
  `id_cuenta_pk` int(11) DEFAULT NULL,
  `id_proveedor_pk` int(11) DEFAULT NULL,
  PRIMARY KEY (`detalle_cuenta_por_pagar_pk`),
  KEY `Refcuenta_corriente_por_pagar12` (`id_cuenta_pk`,`id_proveedor_pk`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_cuenta_por_pagar`
--

LOCK TABLES `detalle_cuenta_por_pagar` WRITE;
/*!40000 ALTER TABLE `detalle_cuenta_por_pagar` DISABLE KEYS */;
INSERT INTO `detalle_cuenta_por_pagar` VALUES (1,'10/27/2016','AD333Q',44,NULL,44,'ACTIVO',1,1),(2,NULL,NULL,NULL,NULL,0,'ACTIVO',2,2),(3,'10/28/2016','AD444Q',44,NULL,88,'ACTIVO',1,1);
/*!40000 ALTER TABLE `detalle_cuenta_por_pagar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_pedido_compra`
--

DROP TABLE IF EXISTS `detalle_pedido_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_pedido_compra` (
  `id_detalle_pk` int(11) NOT NULL AUTO_INCREMENT,
  `id_orden_compra_pk` int(11) NOT NULL,
  `id_detalle_requisicion_pk` int(11) DEFAULT NULL,
  `estado` char(30) DEFAULT 'ACTIVO',
  PRIMARY KEY (`id_detalle_pk`,`id_orden_compra_pk`),
  KEY `Refpedido_compra6` (`id_orden_compra_pk`),
  KEY `Refdetalle_requisicion10` (`id_detalle_requisicion_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_pedido_compra`
--

LOCK TABLES `detalle_pedido_compra` WRITE;
/*!40000 ALTER TABLE `detalle_pedido_compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_pedido_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_requisicion`
--

DROP TABLE IF EXISTS `detalle_requisicion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_requisicion` (
  `id_detalle_requisicion_pk` int(11) NOT NULL AUTO_INCREMENT,
  `cantidad` int(11) DEFAULT NULL,
  `estado` char(30) DEFAULT 'ACTIVO',
  PRIMARY KEY (`id_detalle_requisicion_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_requisicion`
--

LOCK TABLES `detalle_requisicion` WRITE;
/*!40000 ALTER TABLE `detalle_requisicion` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_requisicion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empleado`
--

DROP TABLE IF EXISTS `empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empleado` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) DEFAULT NULL,
  `apellido` varchar(60) DEFAULT NULL,
  `descripcion` varchar(11) NOT NULL,
  `estado` varchar(45) NOT NULL DEFAULT 'ACTIVO',
  `Fecha` date DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleado`
--

LOCK TABLES `empleado` WRITE;
/*!40000 ALTER TABLE `empleado` DISABLE KEYS */;
INSERT INTO `empleado` VALUES (1,'hola','adios','0','INACTIVO',NULL),(2,'Andrea','c','0','ACTIVO',NULL),(3,'b','c','0','ACTIVO',NULL),(4,'b','c','0','ACTIVO',NULL),(5,NULL,NULL,'0','ACTIVO',NULL),(6,NULL,NULL,'0','ACTIVO',NULL),(7,'Javier','Figueroa','0','ACTIVO',NULL),(8,'Javier','Figueroa','0','ACTIVO',NULL),(9,'Cristian','Estrada','0','ACTIVO',NULL),(10,'nilson','reguan','0','ACTIVO',NULL),(11,'Otto','hernandez','0','ACTIVO',NULL),(12,NULL,NULL,'0','ACTIVO',NULL),(13,'1','perro','0','ACTIVO',NULL),(14,'hola','arcilla','0','ACTIVO',NULL),(15,NULL,NULL,'0','ACTIVO',NULL),(16,'hola','herrera','0','ACTIVO',NULL),(17,'Javier','sdasa','0','ACTIVO',NULL),(18,'Hola','Nenas','0','ACTIVO',NULL),(19,'hola','como ','0','ACTIVO',NULL),(20,'manuel','que','0','ACTIVO',NULL),(21,'hola','Hernandez','0','ACTIVO','2016-09-23'),(22,'Otto','Hernandez','0','ACTIVO',NULL),(23,'Otto','Hernandez','0','ACTIVO',NULL),(24,'andrea','Lopeza','0','ACTIVO',NULL),(25,'hola','adios','0','ACTIVO',NULL),(26,'Hola','como','0','ACTIVO',NULL),(27,'hola','24','0','ACTIVO',NULL),(28,'hola','sdas','0','ACTIVO',NULL),(29,'hola','24','0','ACTIVO',NULL),(30,'hola','raiz','24','ACTIVO',NULL),(31,'hola','Hernandez','0','INACTIVO','2016-09-29'),(32,'hola','Hermosa','Zimeri','ACTIVO','2016-10-24');
/*!40000 ALTER TABLE `empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gastos_importacion`
--

DROP TABLE IF EXISTS `gastos_importacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gastos_importacion` (
  `id_importacion_pk` int(11) NOT NULL AUTO_INCREMENT,
  `transporte` char(25) DEFAULT NULL,
  `direccion_salida` char(25) DEFAULT NULL,
  `hora_fecha_salida` date DEFAULT NULL,
  `direccion_llegada` char(25) DEFAULT NULL,
  `hora_fecha_llegada` date DEFAULT NULL,
  `aduana` decimal(15,0) DEFAULT NULL,
  `otros_impuestos` decimal(15,0) DEFAULT NULL,
  `estado` char(30) DEFAULT 'ACTIVO',
  `id_factura_pk` int(11) NOT NULL,
  PRIMARY KEY (`id_importacion_pk`),
  KEY `Refcompra5` (`id_factura_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gastos_importacion`
--

LOCK TABLES `gastos_importacion` WRITE;
/*!40000 ALTER TABLE `gastos_importacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `gastos_importacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `obtenerdetalle`
--

DROP TABLE IF EXISTS `obtenerdetalle`;
/*!50001 DROP VIEW IF EXISTS `obtenerdetalle`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `obtenerdetalle` AS SELECT 
 1 AS `nombre_proveedor`,
 1 AS `id_proveedor_pk`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `pedido_compra`
--

DROP TABLE IF EXISTS `pedido_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedido_compra` (
  `id_orden_compra_pk` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `encargado` char(25) DEFAULT NULL,
  `estado_pedido` char(20) DEFAULT NULL,
  `observaciones` char(50) DEFAULT NULL,
  `estado` char(20) DEFAULT 'ACTIVO',
  `id_proveedor_pk` int(11) NOT NULL,
  `id_requisicion_pk` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_orden_compra_pk`),
  KEY `Refrequisicion2` (`id_requisicion_pk`),
  KEY `Refproveedor8` (`id_proveedor_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedido_compra`
--

LOCK TABLES `pedido_compra` WRITE;
/*!40000 ALTER TABLE `pedido_compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedido_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor`
--

DROP TABLE IF EXISTS `proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedor` (
  `id_proveedor_pk` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_proveedor` char(25) DEFAULT NULL,
  `direccion` varchar(35) DEFAULT NULL,
  `telefono` char(15) DEFAULT NULL,
  `correo_electronico` char(50) DEFAULT NULL,
  `estado` char(25) DEFAULT 'ACTIVO',
  PRIMARY KEY (`id_proveedor_pk`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor`
--

LOCK TABLES `proveedor` WRITE;
/*!40000 ALTER TABLE `proveedor` DISABLE KEYS */;
INSERT INTO `proveedor` VALUES (1,'EL Bododegon','2 Zona 3','2233-5566','eBodegon@dgmail.com','ACTIVO'),(2,'Buen Precio','3-0 Zona 4','5544-8899','b_prcio@gmail.com','ACTIVO'),(3,'El Don Juan','22-11 Zona 23','3344-2211','el_d-Juan@gmail.com','ACTIVO'),(4,'San JuanVernardo','2da Calle Fondo Zona 1','4466-9022','d_J_vernardo@gmail.com','ACTIVO');
/*!40000 ALTER TABLE `proveedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reporteador`
--

DROP TABLE IF EXISTS `reporteador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reporteador` (
  `id_reporteador` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(25) DEFAULT NULL,
  `ubicacion` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_reporteador`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reporteador`
--

LOCK TABLES `reporteador` WRITE;
/*!40000 ALTER TABLE `reporteador` DISABLE KEYS */;
INSERT INTO `reporteador` VALUES (1,'Proveedores','C:\\Users\\ccarrera\\Desktop\\Entregar\\Prueba\\Prueba\\proveedor.rpt');
/*!40000 ALTER TABLE `reporteador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requisicion`
--

DROP TABLE IF EXISTS `requisicion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requisicion` (
  `id_requisicion_pk` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `encargado` char(50) DEFAULT NULL,
  `estado` char(20) DEFAULT 'ACTIVO',
  `id_detalle_requisicion_pk` int(11) DEFAULT NULL,
  `id_bodega_pk` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_requisicion_pk`),
  KEY `Refdetalle_requisicion1` (`id_detalle_requisicion_pk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requisicion`
--

LOCK TABLES `requisicion` WRITE;
/*!40000 ALTER TABLE `requisicion` DISABLE KEYS */;
/*!40000 ALTER TABLE `requisicion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `obtenerdetalle`
--

/*!50001 DROP VIEW IF EXISTS `obtenerdetalle`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `obtenerdetalle` AS select `proveedor`.`nombre_proveedor` AS `nombre_proveedor`,`detalle_cuenta_por_pagar`.`id_proveedor_pk` AS `id_proveedor_pk` from (`proveedor` join `detalle_cuenta_por_pagar` on((`proveedor`.`id_proveedor_pk` = `detalle_cuenta_por_pagar`.`id_proveedor_pk`))) group by `proveedor`.`id_proveedor_pk` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-10-28 23:47:11
