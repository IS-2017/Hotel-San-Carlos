﻿using System.Windows.Forms;

namespace ComprasProveedores
{
    public partial class GastosImportacion : Form
    {
        public GastosImportacion()
        {
            InitializeComponent();
        }
    }
}
