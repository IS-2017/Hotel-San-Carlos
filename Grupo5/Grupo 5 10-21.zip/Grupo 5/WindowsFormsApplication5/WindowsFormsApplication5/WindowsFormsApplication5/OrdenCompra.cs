﻿using System.Windows.Forms;

namespace WindowsFormsApplication5
{
    public partial class OrdenCompra : Form
    {
        public OrdenCompra()
        {
            InitializeComponent();
        }

        private void OrdenCompra_Load(object sender, System.EventArgs e)
        {

        }
    }
}
