﻿namespace Abrir
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.Btn_nuevo = new System.Windows.Forms.Button();
            this.dgv_crystal = new System.Windows.Forms.DataGridView();
            this.btn_ver = new System.Windows.Forms.Button();
            this.btn_impresora = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_crystal)).BeginInit();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Btn_nuevo
            // 
            this.Btn_nuevo.Image = ((System.Drawing.Image)(resources.GetObject("Btn_nuevo.Image")));
            this.Btn_nuevo.Location = new System.Drawing.Point(229, 12);
            this.Btn_nuevo.Name = "Btn_nuevo";
            this.Btn_nuevo.Size = new System.Drawing.Size(116, 120);
            this.Btn_nuevo.TabIndex = 0;
            this.toolTip1.SetToolTip(this.Btn_nuevo, "Agregar un nuevo RPT");
            this.Btn_nuevo.UseVisualStyleBackColor = true;
            this.Btn_nuevo.Click += new System.EventHandler(this.button1_Click);
            // 
            // dgv_crystal
            // 
            this.dgv_crystal.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_crystal.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_crystal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_crystal.Location = new System.Drawing.Point(6, 152);
            this.dgv_crystal.Name = "dgv_crystal";
            this.dgv_crystal.RowTemplate.Height = 24;
            this.dgv_crystal.Size = new System.Drawing.Size(623, 202);
            this.dgv_crystal.TabIndex = 1;
            // 
            // btn_ver
            // 
            this.btn_ver.Location = new System.Drawing.Point(635, 152);
            this.btn_ver.Name = "btn_ver";
            this.btn_ver.Size = new System.Drawing.Size(45, 23);
            this.btn_ver.TabIndex = 2;
            this.btn_ver.Text = "Ver";
            this.btn_ver.UseVisualStyleBackColor = true;
            this.btn_ver.Click += new System.EventHandler(this.btn_ver_Click);
            // 
            // btn_impresora
            // 
            this.btn_impresora.Location = new System.Drawing.Point(686, 152);
            this.btn_impresora.Name = "btn_impresora";
            this.btn_impresora.Size = new System.Drawing.Size(77, 23);
            this.btn_impresora.TabIndex = 3;
            this.btn_impresora.Text = "Imprimir";
            this.btn_impresora.UseVisualStyleBackColor = true;
            this.btn_impresora.Click += new System.EventHandler(this.btn_impresora_Click);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // toolTip1
            // 
            this.toolTip1.ToolTipTitle = "Agregar un nuevo RPT";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(774, 360);
            this.Controls.Add(this.btn_impresora);
            this.Controls.Add(this.btn_ver);
            this.Controls.Add(this.dgv_crystal);
            this.Controls.Add(this.Btn_nuevo);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_crystal)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button Btn_nuevo;
        private System.Windows.Forms.DataGridView dgv_crystal;
        private System.Windows.Forms.Button btn_ver;
        private System.Windows.Forms.Button btn_impresora;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}